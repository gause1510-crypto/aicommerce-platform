"use client";

import Link from "next/link";
import { useState } from "react";
import styles from "./platform-admin.module.css";

const navGroups = [
  ["PLATFORM", [["⌂","Command center"],["♙","Merchants & users"],["◇","Stores"],["□","Order oversight"],["▣","Catalog oversight"]]],
  ["REVENUE", [["＄","Plans & pricing"],["▤","Billing & payouts"],["％","Promotions"]]],
  ["EXPERIENCE", [["✦","Onboarding assistant"],["◉","Owner popups"],["✣","Platform sandbox"],["▶","AI video maker"]]],
  ["OPERATIONS", [["◎","Usage CRM"],["◍","Support center"],["⌁","Apps & APIs"],["⚿","Account recovery"]]],
  ["CONTROL", [["◈","Risk & compliance"],["↗","Reports"],["≡","Audit logs"],["⚙","Platform settings"]]],
];

const plans = [
  { name: "Starter", price: "$0", place: "Signup + pricing page", visible: true },
  { name: "Growth", price: "Not set", place: "Pricing page", visible: false },
  { name: "Scale", price: "Not set", place: "Contact sales", visible: false },
];

export default function PlatformAdmin(){
  const [active,setActive]=useState("Command center");
  const [popup,setPopup]=useState(false);
  return <main className={styles.shell}>
    <aside className={styles.side}>
      <Link className={styles.brand} href="/"><b>✦</b><span>AiCommerce</span></Link>
      <div className={styles.adminBadge}>PLATFORM ADMIN</div>
      <nav>{navGroups.map(([group,items])=><section key={group as string}><small>{group as string}</small>{(items as string[][]).map(([icon,label])=><button className={active===label?styles.active:""} onClick={()=>setActive(label)} key={label}><i>{icon}</i><span>{label}</span></button>)}</section>)}</nav>
      <div className={styles.identity}><i>D</i><div><b>Dwayne</b><small>Platform owner</small></div></div>
    </aside>

    <section className={styles.main}>
      <header><div className={styles.search}>⌕ <span>Search users, stores, orders, settings</span><kbd>⌘ K</kbd></div><div className={styles.headerActions}><Link href="/dashboard">My stores <b>0/20</b> →</Link><button>◌</button></div></header>
      <div className={styles.content}>
        <div className={styles.heading}><div><small>OWNER CONTROL / {active.toUpperCase()}</small><h1>{active}</h1><p>Control AiCommerce without entering a merchant’s private workspace.</p></div><span className={styles.live}><i/> Platform online</span></div>

        <section className={styles.stats}><article><span>MERCHANT ACCOUNTS</span><b>0</b><small>No accounts yet</small></article><article><span>ACTIVE STORES</span><b>0</b><small>Across the platform</small></article><article><span>ORDERS PROCESSED</span><b>0</b><small>Platform lifetime</small></article><article><span>SUPPORT QUEUE</span><b>0</b><small>Nothing waiting</small></article></section>

        <section className={styles.ownerGrid}>
          <article className={styles.sandbox}><div className={styles.cardHead}><i>✣</i><span>SANDBOX MODE</span></div><h2>Change the platform safely.</h2><p>Use the AI interface builder to redesign or update AiCommerce in an isolated version. Review every change before it can reach the live platform.</p><div className={styles.sandboxFlow}><span>LIVE PLATFORM</span><b>→</b><span>PRIVATE SANDBOX</span><b>→</b><span>REVIEW & PUBLISH</span></div><button>Open platform sandbox →</button></article>
          <article className={styles.onboarding}><div className={styles.cardHead}><i>✦</i><span>AI ONBOARDING</span></div><h3>Owner guidance</h3><p>Configure the assistant that guides new merchants through store setup and required decisions.</p><div className={styles.statusRow}><span>Assistant status</span><b>Ready to configure</b></div><button>Configure guidance →</button></article>
        </section>

        <div className={styles.sectionTitle}><div><small>MONETIZATION</small><h2>Plans, pricing, and placement</h2></div><button>Edit packages</button></div>
        <section className={styles.planTable}><header><span>PACKAGE</span><span>PRICE</span><span>SEEN BY USERS</span><span>STATUS</span><span/></header>{plans.map(plan=><div key={plan.name}><b>{plan.name}</b><span>{plan.price}</span><span>{plan.place}</span><em className={plan.visible?styles.visible:styles.hidden}>{plan.visible?"Visible":"Hidden"}</em><button>•••</button></div>)}</section>

        <section className={styles.controlGrid}>
          <article><i>◉</i><div><small>OWNER COMMUNICATION</small><h3>Popups & announcements</h3><p>Choose which store owners see a message, where it appears, and when it expires.</p></div><button onClick={()=>setPopup(!popup)}>{popup?"Close composer":"Create popup →"}</button>{popup&&<div className={styles.composer}><input aria-label="Popup title" placeholder="Popup title"/><textarea aria-label="Popup message" placeholder="Message for store owners"/><div><select aria-label="Audience"><option>All store owners</option><option>Selected package</option><option>Selected stores</option></select><button>Save draft</button></div></div>}</article>
          <article><i>▶</i><div><small>AI CREATIVE STUDIO</small><h3>AI video maker</h3><p>Create videos for AiCommerce or make the tool available inside selected packages.</p></div><div className={styles.duration}><span>Maximum video length</span><b>60 seconds</b></div><button>Open video studio →</button></article>
          <article><i>◎</i><div><small>PLATFORM CRM</small><h3>User usage & health</h3><p>Track account activity, store usage, package limits, support history, and merchant health.</p></div><button>Open usage CRM →</button></article>
          <article><i>⚿</i><div><small>ACCOUNT RECOVERY</small><h3>Locked-out users</h3><p>Verify the account, unlock access, or send a secure password-reset link. Passwords are never exposed.</p></div><button>Open recovery queue →</button></article>
        </section>

        <div className={styles.sectionTitle}><div><small>USER HELP</small><h2>AI chat and phone support</h2></div><button>Support settings</button></div>
        <section className={styles.support}><article><div className={styles.agent}>A1</div><div><small>AI SUPPORT ONE</small><h3>Chat support</h3><p>Handles platform guidance, store setup questions, and first-line troubleshooting.</p></div><span>Not configured</span><button>Configure →</button></article><article><div className={styles.agent}>A2</div><div><small>AI SUPPORT TWO</small><h3>Phone support</h3><p>Answers user calls, verifies the caller, provides help, and escalates when needed.</p></div><span>Not configured</span><button>Configure →</button></article></section>
      </div>
    </section>
  </main>
}
