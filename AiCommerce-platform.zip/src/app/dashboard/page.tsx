import Link from "next/link";
import styles from "./dashboard.module.css";

const core = [["⌂","Home"],["□","Orders"],["▣","Products"],["♙","Customers"],["▤","Content"],["⌁","Analytics"],["↗","Marketing"],["％","Discounts"],["＄","Finances"]];
const groups = [
  ["SALES CHANNELS",[["◫","Online store"],["⊙","Point of sale"],["＋","Sales channels"]]],
  ["CUSTOMER OPERATIONS",[["◎","CRM"],["◉","Call center"]]],
  ["AI OPERATIONS",[["✦","Onboarding assistant"],["✣","Interface builder"],["⌘","API caller"],["◐","Overnight orders"],["↗","Marketing advisor"]]],
  ["PLATFORM",[["⬡","Apps"],["⚙","Settings"]]],
];

export default function Dashboard(){return <main className={styles.shell}>
  <aside className={styles.side}>
    <Link href="/" className={styles.brand}><b>✦</b><span>AiCommerce</span></Link>
    <button className={styles.switcher}>◇ <span>You have no stores</span><b>⌄</b></button>
    <nav>{core.map(([icon,label],i)=><a className={i===0?styles.active:""} href={i===0?"/dashboard":"#"} key={label}>{icon}<span>{label}</span></a>)}
      {groups.map(([title,items])=><section key={title as string}><small>{title as string}</small>{(items as string[][]).map(([icon,label])=><a href="#" key={label}>{icon}<span>{label}</span></a>)}</section>)}
    </nav>
    <div className={styles.owner}><i>D</i><div><b>Dwayne</b><small>Workspace owner</small></div></div>
  </aside>

  <section className={styles.workspace}>
    <header><div className={styles.search}>⌕ <span>Search AiCommerce</span><kbd>⌘ K</kbd></div><div><button className={styles.alert}>◌</button><button>✦ Create a store</button></div></header>
    <div className={styles.content}>
      <div className={styles.welcome}><div><small>AICOMMERCE / HOME</small><h1>Good evening, Dwayne.</h1></div><span>0 of 10 stores created</span></div>
      <section className={styles.guide}><i>✦</i><div><small>AI ONBOARDING ASSISTANT</small><h3>I’ll guide your build from the first decision.</h3><p>We can define the store, connect its tools, prepare commerce settings, and check every required step together.</p></div><button>Start guided setup →</button></section>
      <section className={styles.builder}><div className={styles.glow}/><div><small>✦ AI INTERFACE BUILDER</small><h2>What kind of store<br/>are we creating?</h2><p>Start with your idea. AiCommerce will shape the interface and structure around it.</p></div><div className={styles.prompt}><textarea aria-label="Describe your store" placeholder="Describe the store you want to build..."/><footer><span>0 of 10 stores in use</span><button>Begin build →</button></footer></div></section>
      <div className={styles.title}><div><small>YOUR NETWORK</small><h2>Stores</h2></div><span>0 of 10 created</span></div>
      <section className={styles.empty}><i>◇</i><h3>Your commerce network starts here</h3><p>Create your first store to open its products, orders, customers, channels, and connected services.</p><button>＋ Create first store</button></section>
      <section className={styles.cards}>
        <article><header><i>◐</i><small>NOT ACTIVE</small></header><h3>Overnight order processor</h3><p>Available after your first store and its order rules are approved.</p><button>View requirements →</button></article>
        <article><header><i>⌘</i><small>NO CONNECTIONS</small></header><h3>AI API caller</h3><p>Connect services and control what AiCommerce can call.</p><button>Open connections →</button></article>
        <article><header><i>↗</i><small>WAITING FOR DATA</small></header><h3>AI marketing advisor</h3><p>Advice begins when a store has real performance data.</p><button>How advice works →</button></article>
      </section>
      <section className={styles.ops}><article><i>◎</i><div><small>CUSTOMER OPERATIONS</small><h3>CRM</h3><p>Profiles, conversations, segments, tasks, and follow-up.</p></div><button>Open CRM →</button></article><article><i>◉</i><div><small>CONNECTED SERVICE</small><h3>Call center</h3><p>Customer calls beside store history, orders, and support.</p></div><button>Open call center →</button></article></section>
    </div>
  </section>
</main>}
