import Link from "next/link";
import styles from "./page.module.css";

const Spark = () => <span className={styles.spark} aria-hidden="true">✦</span>;

const features = [
  ["01", "AI interface builder", "Describe the storefront you want, then shape its pages and customer journey in one visual workspace."],
  ["02", "AI API caller", "Connect outside services and control how each store can use them."],
  ["03", "Up to 10 stores", "Build a network of independent stores from one AiCommerce account."],
  ["04", "Overnight order processor", "Let approved order work continue overnight, then review the completed activity when you return."],
  ["05", "AI marketing advisor", "Turn real store performance into clear guidance for reaching customers and improving growth."],
  ["06", "AI onboarding assistant", "Guide every new owner through setup and the tools they need as they build."],
  ["07", "Built-in CRM", "Keep customer profiles, conversations, activity, and follow-up connected to each store."],
  ["08", "Commerce call center", "Manage customer calls and service beside orders and customer records."],
];

export default function Home() {
  return (
    <main className={styles.page}>
      <nav className={styles.nav} aria-label="Main navigation">
        <Link href="/" className={styles.brand}><Spark />AiCommerce</Link>
        <div className={styles.links}><a href="#platform">Platform</a><a href="#intelligence">AI tools</a><a href="#stores">Stores</a></div>
        <div className={styles.actions}><Link href="/dashboard">Sign in</Link><Link className={styles.pill} href="/dashboard">Start building <b>→</b></Link></div>
      </nav>

      <section className={styles.hero}>
        <div className={styles.glow} />
        <div className={styles.heroCopy}>
          <p className={styles.kicker}><Spark /> AI-NATIVE COMMERCE</p>
          <h1>Build the store.<span>Let AI run the rhythm.</span></h1>
          <p className={styles.lead}>Create, connect, and operate your commerce network from one intelligent platform built around the way you work.</p>
          <div className={styles.heroActions}><Link className={styles.pill} href="/dashboard">Create your first store <b>→</b></Link><a href="#platform">Explore AiCommerce</a></div>
          <p className={styles.limit}><strong>10</strong> stores available in every workspace</p>
        </div>

        <div className={styles.preview} aria-label="AiCommerce interface preview">
          <header><span><Spark /> AI workspace</span><small><i /> Systems ready</small></header>
          <div className={styles.previewBody}>
            <aside><Spark /><i /><i /><i /><i /></aside>
            <section>
              <small>NEW STORE</small><h2>What are we building?</h2><p>Tell AiCommerce how your store should look, feel, and work.</p>
              <div className={styles.prompt}><span>Describe your store idea...</span><button aria-label="Send">→</button></div>
              <div className={styles.miniGrid}><div><small>INTERFACE</small><b>AI generated</b><i /></div><div><small>CONNECTIONS</small><b>API ready</b><em>●—●—●</em></div></div>
              <div className={styles.night}><span>◐</span><div><b>Overnight processor</b><small>Ready after store setup</small></div><i /></div>
            </section>
          </div>
        </div>
      </section>

      <section className={styles.intro} id="platform"><small>THE PLATFORM</small><h2>Not another store dashboard.<br />A new operating system for commerce.</h2></section>

      <section className={styles.grid} id="intelligence">
        {features.map(([number, title, copy], index) => <article className={index === 0 ? styles.wide : ""} key={number}><span>{number}</span><div><h3>{title}</h3><p>{copy}</p></div><div className={styles.visual} aria-hidden="true">{index === 0 ? <><i /><i /><i /></> : index === 2 ? Array.from({length:10}).map((_,i)=><b key={i}>{i+1}</b>) : <strong><Spark /></strong>}</div></article>)}
      </section>

      <section className={styles.final} id="stores"><div className={styles.glow} /><p className={styles.kicker}><Spark /> YOUR NEXT STORE STARTS HERE</p><h2>One idea can become<br />an entire commerce network.</h2><p>Build your first store, then grow into the other nine when you are ready.</p><Link className={styles.pill} href="/dashboard">Open AiCommerce <b>→</b></Link></section>
      <footer className={styles.footer}><Link href="/" className={styles.brand}><Spark />AiCommerce</Link><span>AI-native commerce infrastructure.</span><span>© 2026 AiCommerce</span></footer>
    </main>
  );
}
